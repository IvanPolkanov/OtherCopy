﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallCollisionController : MonoBehaviour
{

    private int _collisionCount =0;

    private void OnCollisionEnter(Collision collision)
    {
        if (_collisionCount == 0)
        {
            WorldRotator.OnBallEndFalling?.Invoke();
        }

        _collisionCount++;
    }

    private void OnCollisionExit(Collision collision)
    {
        _collisionCount--;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Finish"))
        {
            WorldRotator.OnStageFinish?.Invoke();
        }
        else if (other.CompareTag("GameController"))
        {
            WorldRotator.OnBallStartFalling?.Invoke();
        }
    }
}
