﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class WorldRotator : MonoBehaviour
{
    [SerializeField] private Transform _world;

    [Space(20)]

    [Range(0, 100)]
    [SerializeField] private float _rorationSpeed = 1;

    [Range(0, 10)]
    [SerializeField] private float _sensevity = 1;


    [SerializeField] private Transform _ballPosition;
    [SerializeField] private Rigidbody _ball;

    private bool _falling = false;
    public static Action OnStageFinish;
    public static Action OnBallEndFalling;
    public static Action OnBallStartFalling;

    private Vector2 _startPos;
    private Vector2 _direction;

    [Space(60)]
    [Range(-90, 0)]
    [SerializeField] private float _minXRotation;
    [Range(0, 90)]
    [SerializeField] private float _maxXRotation;
    [Space(20)]
    [Range(-90,0)]
    [SerializeField] private float _minZRotation;
    [Range(0, 90)]
    [SerializeField] private float _maxZRotation;

    private float _currentXRotation = 0;
    private float _currentZRotation = 0;

    private void OnEnable()
    {
        OnStageFinish += ResetLevel;
        OnBallEndFalling += BallEndFalling;
        OnBallStartFalling += BallStartFalling;
    }

    private void OnDisable()
    {
        OnStageFinish -= ResetLevel;
        OnBallEndFalling -= BallEndFalling;
        OnBallStartFalling -= BallStartFalling;
    }

    private void Update()
    {
        RotateWorld(GetRotationInput());
    }

    private Vector3 GetRotationInput()
    {
        float xRotation = 0;
        float zRotation = 0;

#if UNITY_EDITOR
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            xRotation = 1;
        }
       else if (Input.GetKey(KeyCode.RightArrow))
        {
            xRotation = -1;
        }

        if (Input.GetKey(KeyCode.UpArrow))
        {
            zRotation = -1;
        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            zRotation = 1;
        }
#endif

#if UNITY_ANDROID
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            switch (touch.phase)
            {
                case TouchPhase.Began:
                    _startPos = touch.position;
                    break;
                case TouchPhase.Moved:
                    _direction = touch.position - _startPos;
                    if (_direction.y < 0)
                    {
                        _currentZRotation -= _rorationSpeed * Time.deltaTime;
                        if (_currentZRotation >= _minZRotation)
                        {
                            zRotation = 1;
                        }
                        else
                        {
                            _currentZRotation = _minZRotation;
                        }
                    }
                    else
                    {
                        _currentZRotation += _rorationSpeed * Time.deltaTime;
                        if (_currentZRotation <= _maxZRotation)
                        {
                            zRotation = -1;
                        }
                        else
                        {
                            _currentZRotation = _maxZRotation;
                        }
                    }

                    if (_direction.x < 0)
                    {
                        _currentXRotation -= _rorationSpeed * Time.deltaTime;
                        if (_currentXRotation >= _minXRotation)
                        {
                            xRotation = 1;
                        }
                        else
                        {
                            _currentXRotation = _minXRotation;
                        }
                       
                    }
                    else
                    {
                        _currentXRotation += _rorationSpeed * Time.deltaTime;
                        if (_currentXRotation <= _maxXRotation)
                        {
                            xRotation = -1;
                        }
                        else
                        {
                            _currentXRotation = _maxXRotation;
                        }
                       
                    }
                    break;
            }
        }
#endif
        return new Vector3(xRotation,0,zRotation);
    }



    private void RotateWorld(Vector3 rotation)
    {
        if (_falling)
        {
            _ball.AddForce(new Vector3(0, -50, 0));
            return;
        }


        _ballPosition.position = _ball.transform.position;
       
        _world.Rotate(rotation * Time.deltaTime*_rorationSpeed);

        _ball.transform.position = _ballPosition.position;

        if (rotation.x != 0)
        {
            Vector3 direction = Vector3.forward * rotation.z *_sensevity + Vector3.right* rotation.x * _sensevity
                + Vector3.up * -50;
            _ball.AddForce(direction);
        }
        else
        {
            _ball.AddForce(new Vector3(0, -50, 0));
        }
    }

    private void ResetLevel()
    {
        _falling = true;

        _currentXRotation = 0;
        _currentZRotation = 0;

        _ball.velocity = new Vector3(0,0,0);

        _world.transform.localEulerAngles = new Vector3();

        _world.transform.position = _ball.transform.position + new Vector3(0, -60, 0);
    }

    private void BallEndFalling()
    {
        _falling = false;
    }

    private void BallStartFalling()
    {
        _falling = true;
    }

}
