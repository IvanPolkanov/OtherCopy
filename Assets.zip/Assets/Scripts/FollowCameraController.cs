﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowCameraController : MonoBehaviour
{
    [SerializeField] private Transform _camera;
    [SerializeField] private Transform _ball;

    [SerializeField] private Vector3 _offset;

    private void LateUpdate()
    {
        _camera.position = _ball.position + _offset;
        _camera.LookAt(_ball);
    }

}
