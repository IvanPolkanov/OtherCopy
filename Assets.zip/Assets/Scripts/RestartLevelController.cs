﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class RestartLevelController : MonoBehaviour
{

    [SerializeField] private Button _onRestartLevel;


    private void OnEnable()
    {
        _onRestartLevel.onClick.AddListener( RestartLevel);
    }

    private void OnDisable()
    {
        _onRestartLevel.onClick.RemoveListener(RestartLevel);
    }

    public void RestartLevel()
    {
        SceneManager.UnloadSceneAsync(SceneManager.GetActiveScene().buildIndex);
        Resources.UnloadUnusedAssets();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
